
class SharedClass:

    def add_two(self, num):
        return num + 2
    
    def sub_one(self, num):
        return num - 1
