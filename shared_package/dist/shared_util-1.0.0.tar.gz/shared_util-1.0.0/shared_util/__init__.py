from .shared_class import SharedClass

__version__ = '1.0.0'
