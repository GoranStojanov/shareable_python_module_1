from setuptools import setup

setup(
    name='shared_util',
    version='1.0.0',
    author='Goran Stojanov',
    author_email='goranstojanov@paymentworks.com',
    description='Test Shareable Utility Module',
    packages=['shared_util'],
    install_requires=[],
)
